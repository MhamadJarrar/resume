var Bio = {
    name: "Mohammad Jarrar ",
    role: "Front End Developer",
    contacts: {
        email: "jarrar.mhamad@gmail.com",
        mobile: "+970 598 973 777",
        twitter: "@Hamodijarrar",
        location: "Palestine",
        github: "@MohdJarrar",
    },
    welcomeMessage: "Hello, Welcome to my resume website.",
    skills: ["Football", "Photography", "Drifting", "Social Media"],
    biopic: "images/Mohd.png",
    display: function() {
        /*Name*/
        var formattedName = HTMLheaderName.replace("%data%", Bio.name);
        $("#header").append(formattedName);
        /*Role*/
        var formattedRole = HTMLheaderRole.replace("%data%", Bio.role);
        $("#header").append(formattedRole);

        /*_____________FOREACH_____________*/
        /*contact*/
        var formattedEmail = HTMLemail.replace(/%data%/gi, Bio.contacts.email);
        $("#header").append(formattedEmail);
        $("#lets-connect").append(formattedEmail);


        var formattedMobile = HTMLmobile.replace(/%data%/gi, Bio.contacts.mobile);
        $("#header").append(formattedMobile);
        $("#lets-connect").append(formattedMobile);

        var formattedtwitter = HTMLtwitter.replace(/%data%/gi, Bio.contacts.twitter);
        $("#header").append(formattedtwitter);
        $("#lets-connect").append(formattedtwitter);

        var formattedGithub = HTMLgithub.replace(/%data%/gi, Bio.contacts.github);
        $("#header").append(formattedGithub);
        $("#lets-connect").append(formattedGithub);

        var formattedLocation = HTMLlocation.replace(/%data%/gi, Bio.contacts.location);
        $("#header").append(formattedLocation);
        $("#lets-connect").append(formattedLocation);



        /*pitcure*/
        var formatedPic = HTMLbioPic.replace("%data%", Bio.biopic);
        $("#header").append(formatedPic);

        /*Welcome Message*/
        var formattedWelcomeMsg = HTMLwelcomeMsg.replace("%data%", Bio.welcomeMessage);
        $("#header").append(formattedWelcomeMsg);

        /*Skills*/
        $("#header").append(HTMLskillsStart); //foreach all
        for (var i = 0; i <= Bio.skills.length - 1; i++) {
            var Skills = HTMLskills.replace("%data%", Bio.skills[i]);
            $("#header").append(Skills);
        };


    }
};

Bio.display();




/*___________________________________________WorkExperience______________________________________________________________*/
var Work = {
    "work": [{
            name: "Conceptes technologies Ltd.",
            title: "Graphic designer and social media marketing",
            Location: "Ramallah",
            description: "i worked with teams on advertsiments projects and social media and digital media marketingi worked with teams on advertsiments projects and social media and digital media marketingi worked with teams on advertsiments projects and social media and digital media marketingi worked with teams on advertsiments projects and social media and digital media marketing",
            date: "August 2016 to December 2016",
        },
        {
            name: "FreeLance",
            title: "Graphic designer and social media marketing",
            Location: "Ramallah",
            description: "i worked with teams on advertsiments projects and social media and digital media marketingi worked with teams on advertsiments projects and social media and digital media marketingi worked with teams on advertsiments projects and social media and digital media marketingi worked with teams on advertsiments projects and social media and digital media marketing",
            date: "May 2016 to December 2016",

        },
    ],
    display: function() {
        /*work experince*/
        $("#workExperience").append(HTMLworkStart);
        /*title*/
        for (var count = 0; count <= Work.work.length - 1; count++) {
            var Workemployer = HTMLworkEmployer.replace("%data%", Work.work[count].name);
            var Worktitle = HTMLworkTitle.replace("%data%", Work.work[count].title);
            var res = Workemployer.concat(Worktitle);
            $("#workExperience").append(res);
            /*date*/
            var Workdate = HTMLworkDates.replace("%data%", Work.work[count].date);
            $("#workExperience").append(Workdate);
            /*location*/
            var WorkLocation = HTMLworkLocation.replace("%data%", Work.work[count].Location);
            $("#workExperience").append(WorkLocation);
            /*description*/
            var WorkDesc = HTMLworkDescription.replace("%data%", Work.work[count].description);
            $("#workExperience").append(WorkDesc);
        }

    }
}
Work.display();

/*___________________________________________project______________________________________________________________*/
var projects = {
    "project": [{
            title: "Sakani website",
            date: "2015 - 2017",
            description: "Skakani is web based application and it's assitant for students in unversitess Skakani is web based application and it's assitant for students in unversitess Skakani is web based application and it's assitant for students in unversitess Skakani is web based application and it's assitant for students in unversitess Skakani is web based application and it's assitant for students in unversitess Skakani is web based application and it's assitant for students in unversitess Skakani is web based application and it's assitant for students in unversitess v v Skakani is web based application and it's assitant for students in unversitess Skakani is web based application and it's assitant for students in unversitess Skakani is web based application and it's assitant for students in unversitess. ",
            images: ["images/Project1.jpg", "images/Project1.jpg"], //array of images 
        },
        {
            title: "Interactive website",
            date: "2013 - 2014",
            description: "Interactive website application for multiemdia technology course that we took with dr. mohd maree, in Secondary year in university Interactive website application for multiemdia technology course that we took with dr. mohd maree Interactive website application for multiemdia technology course that we took with dr. mohd maree Interactive website application for multiemdia technology course that we took with dr. mohd maree Interactive website application for multiemdia technology course that we took with dr. mohd maree Interactive website application for multiemdia technology course that we took with dr. mohd maree. ",
            images: ["images/interactive.jpg"], //array of images 
        },
    ],
    display: function() {
        for (var count = 0; count <= projects.project.length - 1; count++) {
            $("#projects").append(HTMLprojectStart);
            var formattedTitle = HTMLprojectTitle.replace("%data%", projects.project[count].title);
            $("#projects").append(formattedTitle);
            var formattedDates = HTMLprojectDates.replace("%data%", projects.project[count].date);
            $("#projects").append(formattedDates);
            var formattedDescription = HTMLprojectDescription.replace("%data%", projects.project[count].description);
            $("#projects").append(formattedDescription);
            for (var i = 0; i <= projects.project[0].images.length - 1; i++) {
                var formattedImages = HTMLprojectImage.replace("%data%", projects.project[count].images[i]);
                $("#projects").append(formattedImages);
            }
        }


    }
}
projects.display();


/*___________________________________________education______________________________________________________________*/
var education = {
    "schools": [{
            name: "Muscat Secondary school",
            location: "NY",
            degree: "tawjehi",
            majors: "industry",
            date: "2011 - 2013",
        },
        {
            name: "Arab American Unviersty",
            location: "Jenin",
            degree: "BA.",
            majors: "Multimedia Technology",
            date: "2013 - 2017",

        },
    ],
    "onlineCourses": [{
        title: "fornt-end developer",
        school: "udacity",
        date: "2017 - 2018",
        url: "www.udacity.com/Front-End-developer-nano-degree.html"
    }, ],
    display: function() {

        $("#education").append(HTMLschoolStart);
        for (var count = 0; count <= education.schools.length - 1; count++) {
            /*name*/
            var formattedSchoolName = HTMLschoolName.replace("%data%", education.schools[count].name);
            var formattedSchoolDegree = HTMLschoolDegree.replace("%data%", education.schools[count].degree);
            var ress = formattedSchoolName.concat(formattedSchoolDegree);
            $("#education").append(ress);
            /*date*/
            var formattedSchoolDate = HTMLschoolDates.replace("%data%", education.schools[count].date);
            $("#education").append(formattedSchoolDate);
            /*location*/
            var formattedSchoolLocation = HTMLschoolLocation.replace("%data%", education.schools[count].location);
            $("#education").append(formattedSchoolLocation);
            /*major*/
            var formattedSchoolMajor = HTMLschoolMajor.replace("%data%", education.schools[count].majors);
            $("#education").append(formattedSchoolMajor);
        }

        /*Course Online*/
        for (var how = 0; how <= education.onlineCourses.length - 1; how++) {
            $("#education").append(HTMLonlineClasses);
            var formattedSchoolCourse = HTMLonlineTitle.replace("%data%", education.onlineCourses[how].title);
            var formattedSchoolSchool = HTMLonlineSchool.replace("%data%", education.onlineCourses[how].school);
            var result = formattedSchoolCourse.concat(formattedSchoolSchool);
            $("#education").append(result);

            var formattedSchoolDate = HTMLonlineDates.replace("%data%", education.onlineCourses[how].date);
            $("#education").append(formattedSchoolDate);

            var formattedURL = HTMLonlineURL.replace("%data%", education.onlineCourses[how].url);
            $("#education").append(formattedURL);
        }

    }
};

education.display();

/*Map*/

$("#mapDiv").append(internationalizeButton);
$("#mapDiv").append(googleMap);